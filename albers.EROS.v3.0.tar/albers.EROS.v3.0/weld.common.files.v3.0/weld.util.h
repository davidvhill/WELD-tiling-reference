/*	Function "strdup" is not in the standard library, although most compilers have their own version.
	Implement it but avoid the name conflict.
*/
char *mystrdup(char *s);

int day_of_year(int year, int month, int day);

int16 asInt16(double x);


